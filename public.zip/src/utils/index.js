import * as APPROUTES from "./AppDataRoutes";
export{
    APPROUTES
}