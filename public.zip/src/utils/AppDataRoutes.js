export let SERVER_URL = "";

export let DATAURLS = {
    
}