function Add(a,b){
    return a+b;
}

export default Add;