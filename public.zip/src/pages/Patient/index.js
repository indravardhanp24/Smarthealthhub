import Prescriptions from "./Prescriptions";
import Symptoms from "./Symptoms";
import Records from "./Records";
import Reminders from "./Reminders";
import Appointments from "./Appointments";
export{
   Prescriptions,
   Symptoms,
   Records, 
   Reminders,
   Appointments,
}