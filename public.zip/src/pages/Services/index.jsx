import React from 'react'
import { Header, HeaderHero } from '../../components';

const ServicesPage = () => {
  return (
    <div className='body' >
        <Header/>
        <div className='wrapper' >
          <HeaderHero heading={"Services"}/>
        <p>
          Lorem ipsum dolor sit amet 
          consectetur adipisicing elit. 
          Saepe et, omnis aspernatur, minus soluta maxime nobis nihil
           animi quae, nisi quis quos excepturi laudantium 
           magni iste modi quidem repellendus ratione.
        </p>
        </div>
        
        
    </div>
  )
}

export default ServicesPage;