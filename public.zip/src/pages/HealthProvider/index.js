import Appointments from "./Appointments";
import Dashboard from "./Dashboard";
import Records from "./Records";
import Eprescriptions from "./Eprescriptions";
export{
    Appointments,
    Dashboard,
    Records,
    Eprescriptions
}