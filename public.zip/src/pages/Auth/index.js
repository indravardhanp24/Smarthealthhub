import LoginPage from "./LoginPage";
import RegistrationPage from "./RegistrationPage";
import ForgotPasswordPage from "./ForgotPasswordPage";

export{
    LoginPage,
    RegistrationPage,
    ForgotPasswordPage
}