import React from 'react'
import { Header, HeaderHero } from '../../components';

const AboutPage = () => {
  return (
    <div className='body' >
      <Header/>
      <div className='wrapper' >
      <HeaderHero heading={"About us"} />

      <p>
        Lorem, ipsum dolor sit amet 
        consectetur adipisicing elit. Possimus, doloremque? Quasi 
        minus quod, distinctio, amet praesentium suscipit, 
        veniam ut placeat sint enim quas? Aliquam, error non totam ipsam voluptatibus deserunt.
      </p>
      </div>
      </div>
  )
}

export default AboutPage;