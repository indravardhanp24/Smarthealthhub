import MedicalHistory from "./MedicalHistory";
import Medicines from "./Medicines";
import MedicineDispensation from "./MedicineDispensation";
export{
    MedicalHistory,
    Medicines,
    MedicineDispensation,
}