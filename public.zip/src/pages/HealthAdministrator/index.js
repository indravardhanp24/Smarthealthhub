import Compliance from "./Compliance";
import Facilities from "./Facilities";
import Incidences from "./Incidences";
import Staff from "./Staff";
export{
    Compliance,
    Facilities,
    Incidences,
    Staff
}